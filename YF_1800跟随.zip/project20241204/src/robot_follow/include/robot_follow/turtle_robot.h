#ifndef TURTLE_ROBOT_H
#define TURTLE_ROBOT_H
#include "ros/ros.h"
#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include "geometry_msgs/PoseStamped.h"
#include "tf2/LinearMath/Quaternion.h"
#include "robot_follow/general_robot.h"

namespace turtle_robot{
    // 机器人
    class Turtle: public general_robot::Robot
    {
        public:
            /**
             * @brief 机器人对象默认构造函数
             **/
            Turtle(); 
            /**
             * @brief 机器人构造函数
             * @param[in]: name -> 机器人名字
             * @retval: None
             **/  
            Turtle(std::string name);
            /**
             * @brief 机器人对象默认析构函数
             **/
            ~Turtle();
           /**
            * @brief 初始化函数
            * @param[in]: name -> 机器人名字
            * @retval: None
            **/ 
            void initialize(std::string name);
           /**
            * @brief 驱动机器人运动
            * @param[in]: cmd -> 运动控制消息
            * @retval: None
            **/ 
            void driveRobot(geometry_msgs::Twist cmd);
           /**
            * @brief 设置机器人起始位姿
            * @param[in]: pose -> 起始位姿
            * @retval: None
            **/ 
            void setStart(general_robot::Pose pose);
            /**
             * @brief 设置机器人起始位姿
             * @param[in]: pose -> 起始位姿
             * @retval: None
             **/ 
            void setGoal(general_robot::Pose pose);

        public:
            // 机器人名字
            std::string m_name;
            // 机器人起点
            general_robot::Pose m_start;
            // 机器人终点
            general_robot::Pose m_goal;

        private:
            // 初始化标志
            bool __initialized;
            // 初始位置发布者
            ros::Publisher __startPub;
            // 目标位置发布者
            ros::Publisher __goalPub;
            // 目标位置发布者
            ros::Publisher __ctrlPub;
            // 全局绝对坐标系
            std::string __absFrameId;
            // 控制指令
            std::string __ctrlCmd;
    };


    
}
#endif