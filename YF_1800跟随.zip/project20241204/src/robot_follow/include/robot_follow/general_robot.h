#ifndef GENERAL_ROBOT_H
#define GENERAL_ROBOT_H
#include "ros/ros.h"
#include "geometry_msgs/Twist.h"

namespace general_robot{
    // @breif: 位姿
    class Pose
    {
        public:
            float x;
            float y;
            float theta;
            Pose()
            {
                this->x = 0;
                this->y = 0;
                this->theta = 0;
            };
            Pose(float x, float y, float theta) 
            {
                this->x = x;
                this->y = y;
                this->theta = theta;
            }
    };

    // 机器人
    class Robot
    {
        public:
            /**
             * @brief 机器人对象默认构造函数
             **/
            Robot(); 
            /**
             * @brief 机器人构造函数
             * @param[in]: name -> 机器人名字
             * @retval: None
             **/  
            Robot(std::string name);
            /**
             * @brief 机器人对象默认析构函数
             **/
            virtual ~Robot() {};
           /**
            * @brief 初始化函数接口
            * @param[in]: name -> 机器人名字
            * @retval: None
            **/ 
            virtual void initialize(std::string name) = 0;
           /**
            * @brief 驱动机器人运动接口
            * @param[in]: cmd -> 运动控制消息
            * @retval: None
            **/ 
            virtual void driveRobot(geometry_msgs::Twist cmd) = 0;

           /**
            * @brief 设置机器人全局绝对坐标系
            * @param[in]: frameId -> 坐标系id
            * @retval: None
            **/ 
            void setAbsFrame(std::string frameId);
           /**
            * @brief 设置机器人控制指令
            * @param[in]: ctrlCmd -> 控制指令话题名
            * @retval: None
            **/ 
            void setCtrlCmd(std::string ctrlCmd);

        public:
            // 机器人名字
            std::string m_name;

        private:
            // 初始化标志
            bool __initialized;
            // 全局绝对坐标系
            std::string __absFrameId;
            // 控制指令
            std::string __ctrlCmd;
    };
    
}
#endif