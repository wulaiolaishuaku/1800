/***********************************************************
 * 
 * @file: multiCtrl.cpp
 * @breif: multi-wheeled mobile robots(M-wmr) control using ROS
 * @author: 1851738 Yang Haodong
 * @update: 2021-12-28
 * @version: 2.0
 * 
 * --------------------------------------------------------
 *
 **********************************************************/
#include "robot_follow/general_robot.h"

namespace general_robot {
    /**
     * @brief 机器人对象的默认构造函数
     **/
    Robot::Robot():
        __initialized(false), __absFrameId("map"), __ctrlCmd("/cmd_vel"){

    }

    /**
    * @brief 设置机器人全局绝对坐标系
    * @param[in]: frameId -> 坐标系id
    * @retval: None
    **/ 
    void Robot::setAbsFrame(std::string frameId)
    {
        this->__absFrameId = frameId;
    }
    /**
    * @brief 设置机器人控制指令
    * @param[in]: ctrlCmd -> 控制指令话题名
    * @retval: None
    **/ 
    void Robot::setCtrlCmd(std::string ctrlCmd)
    {
        this->__ctrlCmd = ctrlCmd;
    }

}