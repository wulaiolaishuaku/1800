#include "robot_follow/turtle_robot.h"

namespace turtle_robot {
    /**
     * @brief 机器人对象的默认构造函数
     **/
    Turtle::Turtle():
        __initialized(false), __absFrameId("map"), __ctrlCmd("/cmd_vel"){

    }
    /**
     * @brief 机器人构造函数
     * @param[in]: name -> 机器人名字
     * @retval: None
     **/  
    Turtle::Turtle(std::string name) : Turtle() {
        this->initialize(name);
    }
    /**
     * @brief 机器人对象默认析构函数
     **/
    Turtle::~Turtle(){

    }
    /**
     * @brief 初始化函数
     * @param[in]: name -> 机器人名字
     * @retval: None
     **/  
    void Turtle::initialize(std::string name)
    {
        if(!__initialized) {
            this->m_name = name;
            ros::NodeHandle privateNh("~/" + name);

            // 发布者初始化
            this->__startPub = privateNh.advertise<geometry_msgs::PoseWithCovarianceStamped>("/" + name + "/initialpose", 1);
            this->__goalPub = privateNh.advertise<geometry_msgs::PoseStamped>("/" + name + "/move_base_simple/goal", 1);
            this->__ctrlPub = privateNh.advertise<geometry_msgs::Twist>("/" + name + this->__ctrlCmd, 2);

            this->__initialized = true;
        }
        else    ROS_WARN("This robot has already been initialized, you can't call it twice, doing nothing");
    }
    /**
     * @brief 设置机器人起始位姿
     * @param[in]: pose -> 起始位姿
     * @retval: None
     **/ 
    void Turtle::setStart(general_robot::Pose pose)
    {
        if(!__initialized)
        {
            ROS_ERROR("This robot has not been initialized yet, but it is being used, please call initialize() before use");
            return;
        }
        else
        {
            this->m_start = pose;
            geometry_msgs::PoseWithCovarianceStamped poseMsg;
            poseMsg.header.stamp = ros::Time::now();
            poseMsg.header.frame_id = this->__absFrameId;
            poseMsg.pose.pose.position.x = pose.x;
            poseMsg.pose.pose.position.y = pose.y;
            poseMsg.pose.pose.position.z = 0.0;
            poseMsg.pose.covariance[0] = 0.25;
            poseMsg.pose.covariance[6 * 1 + 1] = 0.25;
            poseMsg.pose.covariance[6 * 5 + 5] = 0.06853891945200942;
            tf2::Quaternion qtn;
            qtn.setRPY(0, 0, pose.theta);
            poseMsg.pose.pose.orientation.x = qtn.getX();
            poseMsg.pose.pose.orientation.y = qtn.getY();
            poseMsg.pose.pose.orientation.z = qtn.getZ();
            poseMsg.pose.pose.orientation.w = qtn.getW();
            this->__startPub.publish(poseMsg);
            ros::Duration d(1);
            d.sleep();
            this->__startPub.publish(poseMsg);
            
        }
    }
    /**
     * @brief 设置机器人起始位姿
     * @param[in]: pose -> 起始位姿
     * @retval: None
     **/ 
    void Turtle::setGoal(general_robot::Pose pose)
    {
        if(!__initialized)
        {
            ROS_ERROR("This robot has not been initialized yet, but it is being used, please call initialize() before use");
            return;
        }
        else
        {
            this->m_goal = pose;
            geometry_msgs::PoseStamped poseMsg;
            poseMsg.header.stamp = ros::Time::now();
            poseMsg.header.frame_id = this->__absFrameId;
            poseMsg.pose.position.x = pose.x;
            poseMsg.pose.position.y = pose.y;
            poseMsg.pose.position.z = 0.0;
            tf2::Quaternion qtn;
            qtn.setRPY(0, 0, pose.theta);
            poseMsg.pose.orientation.x = qtn.getX();
            poseMsg.pose.orientation.y = qtn.getY();
            poseMsg.pose.orientation.z = qtn.getZ();
            poseMsg.pose.orientation.w = qtn.getW();
            this->__goalPub.publish(poseMsg);
            ros::Duration d(1);
            d.sleep();
            this->__goalPub.publish(poseMsg);
        }
    }
    /**
    * @brief 驱动机器人运动
    * @param[in]: cmd -> 运动控制消息
    * @retval: None
    **/ 
    void Turtle::driveRobot(geometry_msgs::Twist cmd)
    {
        this->__ctrlPub.publish(cmd);
    }


}