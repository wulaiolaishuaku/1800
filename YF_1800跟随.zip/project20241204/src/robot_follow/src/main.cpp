#include "ros/ros.h"
#include "std_msgs/String.h"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_ros/transform_listener.h"
#include "robot_follow/turtle_robot.h"

#define PI 3.1415926

std::vector<turtle_robot::Turtle> robotInitialization()
{
    std::vector<turtle_robot::Turtle> robots;
    turtle_robot::Turtle robot1("robot1");
    general_robot::Pose start;
    start.x = 0.0;
    start.y = 0.0;
    start.theta = 0.0;
    robot1.setStart(start);
    robots.push_back(robot1);

    turtle_robot::Turtle robot2("robot2");
    start.x = 5.0;
    start.y = 0.0;
    start.theta = 0.0;
    robot2.setStart(start);
    robots.push_back(robot2);
    return robots;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "pose_init");

    std::vector<turtle_robot::Turtle> robots = robotInitialization();

    ros::Rate loop_rate(1);
    tf2_ros::Buffer buffer;
    tf2_ros::TransformListener listener(buffer);
    for (auto &robot : robots)
    {
        robot.setStart(robot.m_start);
    }

    general_robot::Pose goal;

    while (ros::ok())
    {
        // 获得1相对地图的位姿
        geometry_msgs::TransformStamped tfs = buffer.lookupTransform("map", "robot1/base_footprint", ros::Time(0));
        ROS_INFO("[x:%.2f, y:%.2f]", tfs.transform.translation.x, tfs.transform.translation.y);

        goal.x = tfs.transform.translation.x;
        goal.y = tfs.transform.translation.y;
        goal.theta = PI / 2;
        robots[1].setGoal(goal);

        loop_rate.sleep();
        // 6.spin
        ros::spinOnce();
    }
    return 0;
}