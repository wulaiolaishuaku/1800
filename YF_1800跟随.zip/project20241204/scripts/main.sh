source ../devel/setup.bash
roslaunch sim_env main.launch