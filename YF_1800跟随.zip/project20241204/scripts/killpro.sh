killall -9 rosmaster
killall -9 roscore
killall gzserver
killall gzclient
